const fs = require("fs");
const express = require("express");

const app = express();
const logPath = "/var/log/app.log";

app.get("/", (req, res) => {
  const line = `${new Date().toISOString()} - requête reçue}\n`;
  fs.appendFileSync(logPath, line);
  res.send("ça marche");
});

app.listen(3000, () => {

 try {
    const block = Buffer.alloc(1024 * 1024 * 21, "x"); // 20 Mo d’un coup
    fs.appendFileSync(logPath, block);
  console.log("✅ Serveur Node.js démarré sur le port 3000");
  } catch (err) {
    console.error("❌ Erreur serveur : impossible de démarrer le serveur.");
    process.exit(1); // quitte sans révéler la vraie erreur
  }
});