#!/bin/bash
echo "=== Sauvegarde des fichiers ==="

SOURCE="./data"
DEST="./archive"

if [ ! -d "$SOURCE" ]; then
  echo "Erreur : impossible de trouver le dossier source."
  exit 1
fi

cp -r "$SOURCE"/* "$DEST"/
echo "Sauvegarde terminée avec succès."
