import express from "express";
import { readFileSync } from "fs";
import config from "./config.js";

const app = express();

app.listen(config.port, () => {
  try {
    const data = readFileSync("src/data/users.json", "utf-8");
    const users = JSON.parse(data);
    console.log(`Server running on port ${config.port}`);
  } catch (error) {
    console.error("Erreur :", error.message);
  }

});
