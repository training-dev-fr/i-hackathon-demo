import { useState } from "react";
import Editor from "@monaco-editor/react";

export default function PfEditor() {
    const [code, setCode] = useState(`
// Écris ton code .pf ici
VARIABLE("test", 123);
`);


    const [logs, setLogs] = useState(null);

    const sendCode = async () => {
        setLogs("Envoi en cours...");
        try {
            const res = await fetch("http://localhost:3333/execute-pf", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ code }),
            });

            const data = await res.json();
            setLogs(data.output.join('\n'));
        } catch (err) {
            setLogs("Erreur lors de l'envoi");
        }
    };

    return (
        <div style={{ maxWidth: "1400px", margin: "0 auto", padding: "20px" }}>
            <div
                style={{
                    background: "#222",
                    padding: "20px",
                    borderRadius: "12px",
                    color: "white",
                    boxShadow: "0 4px 15px rgba(0,0,0,0.3)",
                }}
            >
                <h1 style={{ fontSize: "24px", marginBottom: "16px", fontWeight: "bold" }}>
                    Éditeur de fichiers .pf
                </h1>

                <Editor
                    height="700px"
                    defaultLanguage="pf"
                    onMount={(editor, monaco) => {
                        monaco.languages.register({ id: "pf" });
                        monaco.editor.defineTheme("pf-theme", {
                            base: "vs-dark",
                            inherit: false,
                            rules: [
                                { token: "keyword", foreground: "2565c0", fontStyle: "bold" },
                                { token: "number", foreground: "88ff88" },
                                { token: "string", foreground: "55ccff" },
                            ],
                            colors: {
                                "editor.background": "#0a0a0a",
                                "editor.foreground": "#e0e0e0",
                                "editorCursor.foreground": "#00ff00",
                                "editor.selectionBackground": "#44444488",
                                "editorLineNumber.foreground": "#555",
                            },
                        });

                        monaco.editor.setTheme("pf-theme");

                        monaco.languages.setMonarchTokensProvider("pf", {
                            tokenizer: {
                                root: [
                                    [/\b(ECRIRE|VARIABLE|POUR|TANT_QUE|SI|CHAINE|LONGUEUR|ALEATOIRE|ABS|PUISSANCE|RACINE|TABLEAU|AJOUTER|RETIRER_DERNIER|OBTENIR|TAILLE|POUR_CHAQUE|DICO|CLE|DEFINIR|CLES|VALEURS|RESET|DEBUG|ET|OU|NON|REPETER|ESSAYER|FICHIER_LIRE|FICHIER_ECRIRE|FICHIER_EXISTE|FICHIER_SUPPRIMER|EnJSON|DepuisJSON)\b/, "keyword"],
                                    [/[0-9]+/, "number"],
                                    [/".*?"/, "string"],
                                ],
                            },
                        });

                        // autocomplete PF
                        const keywords = [
                            "ECRIRE", "VARIABLE", "POUR", "TANT_QUE", "SI", "CHAINE", "LONGUEUR",
                            "ALEATOIRE", "ABS", "PUISSANCE", "RACINE", "TABLEAU", "AJOUTER",
                            "RETIRER_DERNIER", "OBTENIR", "TAILLE", "POUR_CHAQUE", "DICO", "CLE",
                            "DEFINIR", "CLES", "VALEURS", "RESET", "DEBUG", "ET", "OU", "NON",
                            "REPETER", "ESSAYER", "FICHIER_LIRE", "FICHIER_ECRIRE",
                            "FICHIER_EXISTE", "FICHIER_SUPPRIMER", "EnJSON", "DepuisJSON",
                        ];

                        const PF_DOC = {
                            "ECRIRE": {
                                detail: "Afficher un texte",
                                documentation: "ECRIRE(...xs)\n\nAjoute une ligne dans les logs."
                            },

                            "VARIABLE": {
                                detail: "Déclarer une variable",
                                documentation: "VARIABLE(nom, valeur)\n\nDéclare une variable globale."
                            },

                            "POUR": {
                                detail: "Boucle for",
                                documentation:
                                    "POUR(init, cond, step, bloc)\n\nBoucle for.\nTous les arguments sont des fonctions."
                            },

                            "TANT_QUE": {
                                detail: "Boucle while",
                                documentation:
                                    "TANT_QUE(cond, bloc)\n\nExécute bloc() tant que cond() est vrai."
                            },

                            "SI": {
                                detail: "Condition",
                                documentation: "SI(condition, alors, sinon?)\n\n- condition : fonction qui doit retourner true/false\nalors: fonction exécutée si condition == true\nsinon: fonction exécutée si condition == false"
                            },

                            "NON": {
                                detail: "Logique NOT",
                                documentation: "NON(a)\n\nRetourne !a."
                            },

                            "ET": {
                                detail: "Logique AND",
                                documentation: "ET(a, b)\n\nRetourne a && b."
                            },

                            "OU": {
                                detail: "Logique OR",
                                documentation: "OU(a, b)\n\nRetourne a || b."
                            },

                            "CHAINE": {
                                detail: "Convertir en texte",
                                documentation: "CHAINE(x)\n\nRetourne String(x)."
                            },

                            "LONGUEUR": {
                                detail: "Longueur de tableau/texte",
                                documentation: "LONGUEUR(x)\n\nRetourne x.length."
                            },

                            "SOUS_CHAINE": {
                                detail: "Substring",
                                documentation: "SOUS_CHAINE(str, debut, fin)\n\nRetourne str.substring()."
                            },

                            "MAJUSCULE": {
                                detail: "Uppercase",
                                documentation: "MAJUSCULE(str)"
                            },

                            "MINUSCULE": {
                                detail: "Lowercase",
                                documentation: "MINUSCULE(str)"
                            },

                            "ALEATOIRE": {
                                detail: "Nombre aléatoire",
                                documentation: "ALEATOIRE(min, max)\n\nRetourne un entier aléatoire inclusif."
                            },

                            "ABS": {
                                detail: "Valeur absolue",
                                documentation: "ABS(x)"
                            },

                            "PUISSANCE": {
                                detail: "Élever à la puissance",
                                documentation: "PUISSANCE(x, y)"
                            },

                            "RACINE": {
                                detail: "Racine carrée",
                                documentation: "RACINE(x)"
                            },

                            "TABLEAU": {
                                detail: "Créer un tableau",
                                documentation: "TABLEAU(...elts)"
                            },

                            "AJOUTER": {
                                detail: "Ajouter au tableau",
                                documentation: "AJOUTER(tab, elt)"
                            },

                            "RETIRER_DERNIER": {
                                detail: "Pop",
                                documentation: "RETIRER_DERNIER(tab)"
                            },

                            "OBTENIR": {
                                detail: "Accéder à un index",
                                documentation: "OBTENIR(tab, index)"
                            },

                            "TAILLE": {
                                detail: "Taille du tableau",
                                documentation: "TAILLE(tab)"
                            },

                            "POUR_CHAQUE": {
                                detail: "Boucle for-of",
                                documentation: "POUR_CHAQUE(tab, bloc)"
                            },

                            "DICO": {
                                detail: "Créer un dictionnaire",
                                documentation: "DICO(obj)"
                            },

                            "CLE": {
                                detail: "Lire une clé",
                                documentation: "CLE(dico, cle)"
                            },

                            "DEFINIR": {
                                detail: "Définir une clé",
                                documentation: "DEFINIR(dico, cle, valeur)"
                            },

                            "CLES": {
                                detail: "Lister les clés",
                                documentation: "CLES(dico)"
                            },

                            "VALEURS": {
                                detail: "Lister les valeurs",
                                documentation: "VALEURS(dico)"
                            },

                            "RESET": {
                                detail: "Réinitialiser les logs",
                                documentation: "RESET()"
                            },

                            "DEBUG": {
                                detail: "Ajouter un log debug JSON",
                                documentation: "DEBUG(x)"
                            },

                            "REPETER": {
                                detail: "Boucle n fois",
                                documentation: "REPETER(n, bloc)"
                            },

                            "ESSAYER": {
                                detail: "Try / catch",
                                documentation: "ESSAYER(bloc, erreur?)"
                            },

                            "FICHIER_LIRE": {
                                detail: "Lire un fichier virtuel",
                                documentation: "FICHIER_LIRE(chemin)"
                            },

                            "FICHIER_ECRIRE": {
                                detail: "Écrire un fichier virtuel",
                                documentation: "FICHIER_ECRIRE(chemin, contenu)"
                            },

                            "FICHIER_EXISTE": {
                                detail: "Tester l’existence",
                                documentation: "FICHIER_EXISTE(chemin)"
                            },

                            "FICHIER_SUPPRIMER": {
                                detail: "Supprimer un fichier",
                                documentation: "FICHIER_SUPPRIMER(chemin)"
                            },

                            "EnJSON": {
                                detail: "Stringify JSON",
                                documentation: "EnJSON(x)"
                            },

                            "DepuisJSON": {
                                detail: "Parse JSON",
                                documentation: "DepuisJSON(str)"
                            },
                        };
                        monaco.languages.registerCompletionItemProvider("pf", {
                            triggerCharacters: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_".split(""),
                            provideCompletionItems() {
                                const suggestions = Object.entries(PF_DOC).map(([name, data]) => ({
                                    label: name,
                                    kind: monaco.languages.CompletionItemKind.Function,
                                    insertText: name + "(",
                                    detail: data.detail,
                                    documentation: { value: data.documentation }
                                }));

                                return { suggestions };
                            }
                        });


                        monaco.languages.registerHoverProvider("pf", {
                            provideHover(model, position) {
                                const word = model.getWordAtPosition(position);
                                if (!word) return null;

                                const d = PF_DOC[word.word];
                                if (!d) return null;

                                return {
                                    contents: [
                                        { value: `**${word.word}**` },
                                        { value: d.doc }
                                    ]
                                };
                            }
                        });



                        // désactiver les diagnostics JS  
                        monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions({
                            noSemanticValidation: true,
                            noSyntaxValidation: true,
                        });

                        monaco.languages.registerCompletionItemProvider("pf", {
                            triggerCharacters: [], // pas d'autocomplétion automatique
                            provideCompletionItems() {
                                const f = (label, detail, doc) => ({
                                    label,
                                    kind: monaco.languages.CompletionItemKind.Function,
                                    insertText: label + "(",
                                    detail,
                                    documentation: { value: doc }
                                });

                                return {
                                    suggestions: PF_SUGGESTIONS
                                };
                            }
                        });
                    }}
                    value={code}
                    onChange={(value) => setCode(value)}
                    theme="vs-dark"
                    options={{
                        wordBasedSuggestions: false,
                        parameterHints: {
                            enabled: false
                        },
                        quickSuggestions: {
                            other: true,
                            comments: false,
                            strings: false
                        },
                        suggestOnTriggerCharacters: true
                    }}
                />

                <button
                    onClick={sendCode}
                    style={{
                        width: "100%",
                        padding: "14px",
                        borderRadius: "10px",
                        fontSize: "18px",
                        fontWeight: "bold",
                        cursor: "pointer",
                        background: "#4a90e2",
                        border: "none",
                        color: "white",
                        transition: "0.2s",
                    }}
                >
                    Exécuter le fichier
                </button>

                {logs && (
                    <div
                        style={{
                            marginTop: "16px",
                            padding: "12px",
                            background: "#333",
                            borderRadius: "10px",
                            whiteSpace: "pre-wrap"
                        }}
                    >
                        {logs}
                    </div>
                )}
            </div>
        </div>
    );
}