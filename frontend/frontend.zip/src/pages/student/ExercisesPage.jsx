"use client"

import { useState, useEffect } from "react"
import { apiService } from "../../services/api"
import ExerciseList from "../../components/student/ExerciseList"
import ExerciseDetail from "../../components/student/ExerciseDetail"

export default function ExercisesPage() {
  const [exercises, setExercises] = useState([])
  const [selectedExercise, setSelectedExercise] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchExercises = async () => {
      try {
        const {data} = await apiService.exercises.getAll()
        setExercises(data)
        if (data.length > 0) {
          setSelectedExercise(data[0])
        }
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    fetchExercises()
  }, [])

  if (loading) return <div className="text-center py-8">Chargement des exercices...</div>
  if (error) return <div className="text-red-600 text-center py-8">{error}</div>

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
      <ExerciseList exercises={exercises} selectedExercise={selectedExercise} onSelectExercise={setSelectedExercise} />
      {selectedExercise && <ExerciseDetail exercise={selectedExercise} />}
    </div>
  )
}
