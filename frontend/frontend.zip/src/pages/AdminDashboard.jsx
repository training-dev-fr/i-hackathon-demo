import { Routes, Route } from "react-router-dom"
import AdminLayout from "../components/AdminLayout"
import AdminHome from "./admin/AdminHome"
import ExercisesManagement from "./admin/ExercisesManagement"
import GroupsManagement from "./admin/GroupsManagement"

export default function AdminDashboard({ user }) {
  return (
    <AdminLayout user={user}>
      <Routes>
        <Route path="/" element={<AdminHome />} />
        <Route path="/exercises" element={<ExercisesManagement />} />
        <Route path="/groups" element={<GroupsManagement />} />
      </Routes>
    </AdminLayout>
  )
}
