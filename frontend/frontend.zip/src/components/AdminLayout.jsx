"use client"

import { useNavigate, Link, useLocation } from "react-router-dom"
import { LogOut, BarChart3, BookOpen, Users } from "lucide-react"

export default function AdminLayout({ user, children }) {
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    navigate("/login")
  }

  const isActive = (path) => location.pathname.includes(path)

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="w-64 bg-white border-r border-gray-200 shadow-sm">
        <div className="p-6 border-b border-gray">
          <h1 className="text-2xl font-bold text-primary">I-Hackaton</h1>
          <p className="text-sm text-muted mt-1">Admin</p>
        </div>

        <nav className="p-4 space-y-2">
          <Link
            to="/admin"
            className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
              isActive("/admin") && !isActive("/exercises") && !isActive("/groups")
                ? "bg-blue-50 text-primary"
                : "text-foreground hover:bg-gray-50"
            }`}
          >
            <BarChart3 size={20} />
            Tableau de bord
          </Link>
          <Link
            to="/admin/exercises"
            className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
              isActive("/exercises") ? "bg-blue-50 text-primary" : "text-foreground hover:bg-gray-50"
            }`}
          >
            <BookOpen size={20} />
            Exercices
          </Link>
          <Link
            to="/admin/groups"
            className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
              isActive("/groups") ? "bg-blue-50 text-primary" : "text-foreground hover:bg-gray-50"
            }`}
          >
            <Users size={20} />
            Groupes
          </Link>
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <button onClick={handleLogout} className="flex items-center gap-2 btn-outline w-full justify-center">
            <LogOut size={18} />
            Déconnexion
          </button>
        </div>
      </aside>

      <main className="flex-1">
        <header className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <p className="text-sm text-muted">Connecté en tant que: {user?.username}</p>
          </div>
        </header>
        <div className="max-w-7xl mx-auto px-6 py-8">{children}</div>
      </main>
    </div>
  )
}
