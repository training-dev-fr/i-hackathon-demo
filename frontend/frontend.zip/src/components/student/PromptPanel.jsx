"use client"

import { useState, useEffect } from "react"
import { Send, Paperclip, Zap } from "lucide-react"
import { apiService } from "../../services/api"

export default function PromptPanel({ exerciseId, maxTokens }) {
  const [prompt, setPrompt] = useState("")
  const [attachments, setAttachments] = useState([])
  const [tokensRemaining, setTokensRemaining] = useState(maxTokens)
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(false)
  const [estimatedTokens, setEstimatedTokens] = useState(0)

  useEffect(() => {
    fetchTokensAndHistory()
  }, [exerciseId])

  const fetchTokensAndHistory = async () => {
    try {
      const tokens = await apiService.tokens.getRemaining(exerciseId)
      setTokensRemaining(tokens.remaining)
      const hist = await apiService.prompts.getHistory(exerciseId)
      setHistory(hist)
    } catch (err) {
      console.error("Error fetching data:", err)
    }
  }

  const estimateTokens = (text) => {
    // Rough estimation: ~4 characters per token
    return Math.ceil(text.length / 4)
  }

  const handlePromptChange = (e) => {
    const text = e.target.value
    setPrompt(text)
    setEstimatedTokens(estimateTokens(text))
  }

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files)
    setAttachments([...attachments, ...files])
  }

  const handleRemoveAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!prompt.trim()) return
    if (estimatedTokens > tokensRemaining) {
      alert("Pas assez de tokens disponibles")
      return
    }

    setLoading(true)
    try {
      const response = await apiService.prompts.submit(exerciseId, prompt, attachments)
      setHistory([...history, response])
      setPrompt("")
      setAttachments([])
      setEstimatedTokens(0)
      setTokensRemaining(tokensRemaining - estimatedTokens)
    } catch (err) {
      alert("Erreur lors de la soumission: " + err.message)
    } finally {
      setLoading(false)
    }
  }

  const tokenPercentage = (tokensRemaining / maxTokens) * 100

  return (
    <div className="card">
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold flex items-center gap-2">
            <Zap size={18} className="text-yellow-500" />
            Tokens restants
          </h3>
          <span className="text-sm font-mono">
            {tokensRemaining} / {maxTokens}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all ${tokenPercentage > 20 ? "bg-green-500" : "bg-red-500"}`}
            style={{ width: `${tokenPercentage}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <textarea
            value={prompt}
            onChange={handlePromptChange}
            placeholder="Posez votre question à l'IA..."
            className="input-field resize-none h-24"
          />
          <div className="text-xs text-muted mt-1">Tokens estimés: {estimatedTokens}</div>
        </div>

        {attachments.length > 0 && (
          <div className="space-y-2">
            {attachments.map((file, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded border border-gray">
                <span className="text-sm">{file.name}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveAttachment(idx)}
                  className="text-red-600 hover:text-red-700"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-2">
          <label className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
            <Paperclip size={18} />
            <span className="text-sm">Ajouter fichier</span>
            <input type="file" multiple onChange={handleFileSelect} className="hidden" />
          </label>
          <button
            type="submit"
            disabled={loading || !prompt.trim() || estimatedTokens > tokensRemaining}
            className="flex-1 btn-primary flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Send size={18} />
            Envoyer
          </button>
        </div>
      </form>

      {history.length > 0 && (
        <div className="mt-6 pt-6 border-t border-gray">
          <h4 className="font-bold mb-3">Historique</h4>
          <div className="space-y-3 max-h-48 overflow-y-auto">
            {history.map((item, idx) => (
              <div key={idx} className="p-3 bg-gray-50 rounded border border-gray">
                <p className="text-sm font-medium mb-1">Votre prompt:</p>
                <p className="text-sm text-muted mb-2">{item.prompt}</p>
                <p className="text-sm font-medium mb-1">Réponse IA:</p>
                <p className="text-sm">{item.response?.substring(0, 150)}...</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
